#!/usr/bin/env python3
"""Preflight: list unfilled cells and unresolved cross-sheet references."""
import json
import sys
from pathlib import Path

SHEETS = Path(sys.argv[1] if len(sys.argv) > 1 else "sheets")
# cells allowed to be null by design
OPTIONAL = {("audio", "replaces"), ("audio", "lowpass_hz"), ("modes", "players_max")}


def load(name):
    return json.loads((SHEETS / f"{name}.json").read_text())


lens, audio, modes, hooks = (load(n) for n in ("lens_effects", "audio", "modes", "hooks"))
issues = []

for name, sheet in (("lens_effects", lens), ("audio", audio), ("modes", modes), ("hooks", hooks)):
    for row in sheet["rows"]:
        for col, val in row.items():
            if val is None and (name, col) not in OPTIONAL:
                issues.append(f"UNFILLED  {name}.{row['id']}.{col}")
            if col == "verified_in_game" and val is False:
                issues.append(f"UNVERIFIED {name}.{row['id']}")

hook_ids = {r["id"] for r in hooks["rows"]}
lens_ids = {r["id"] for r in lens["rows"]}
audio_ids = {r["id"] for r in audio["rows"]}
for r in lens["rows"]:
    if r["render_hook"] not in hook_ids:
        issues.append(f"BROKEN REF lens_effects.{r['id']}.render_hook -> {r['render_hook']}")
for r in audio["rows"]:
    if r["audio_hook"] not in hook_ids:
        issues.append(f"BROKEN REF audio.{r['id']}.audio_hook -> {r['audio_hook']}")
mode_ids = {r["id"] for r in modes["rows"]}
for r in lens["rows"]:
    for m in r["applies_in"]:
        if m not in mode_ids:
            issues.append(f"BROKEN REF lens_effects.{r['id']}.applies_in -> {m}")
for r in modes["rows"]:
    for e in r["effects"]:
        if e not in lens_ids:
            issues.append(f"BROKEN REF modes.{r['id']}.effects -> {e}")
    for a in r["audio"]:
        if a not in audio_ids:
            issues.append(f"BROKEN REF modes.{r['id']}.audio -> {a}")

broken = [i for i in issues if i.startswith("BROKEN")]
unfilled = [i for i in issues if i.startswith("UNFILLED")]
unverified = [i for i in issues if i.startswith("UNVERIFIED")]
print("\n".join(issues))
print(f"\n{len(broken)} broken references, {len(unfilled)} unfilled cells, "
      f"{len(unverified)} unverified rows")
sys.exit(1 if issues else 0)
